library(testthat)
library(sqlhelper)

test_check("sqlhelper")

