-- quotesql = foo
select 1
