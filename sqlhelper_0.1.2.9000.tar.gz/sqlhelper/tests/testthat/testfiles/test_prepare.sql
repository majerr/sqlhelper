-- qname = selectn
SELECT {n};

-- qname = select1
-- quotesql = no
-- execmethod = execute
SELECT 1;

-- qname = foocon
-- conn_name = foo
-- execmethod = spatial
-- geometry = geom
select 'foo';
