-- execmethod = foo
select 1
