SELECT * FROM IRIS WHERE species %LIKE% {species}
