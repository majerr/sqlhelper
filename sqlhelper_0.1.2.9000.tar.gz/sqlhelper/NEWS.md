# sqlhelper (development version)

# sqlhelper 0.1.3

# sqlhelper 0.1.2

## Bug fixes

* `runfiles()` error preparing multiple files (#1)

# sqlhelper 0.1.1

* Added a `NEWS.md` file to track changes to the package.
